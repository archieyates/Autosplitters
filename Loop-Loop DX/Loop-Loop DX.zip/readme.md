# Loop-Loop DX Autosplitter
## Supported Features
- Split
## Supported Categories
### Adventure Mode
- Completing each major area
- Dealing the final hit to The Warden

## Additional Info
- SRC board: https://www.speedrun.com/loop_loop
- Requires asl-help component (comes bundled with the autosplitter when downloaded via Livesplit)
  - Manual download available at: https://github.com/just-ero/asl-help/blob/main/lib/asl-help